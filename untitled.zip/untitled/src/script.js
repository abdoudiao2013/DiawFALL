<script>
function validateForm() {
    const name = document.forms["contactForm"]["name"].value;
    const email = document.forms["contactForm"]["email"].value;
    if (name === "" || email === "") {
        alert("Veuillez remplir tous les champs !");
        return false;
    }
    alert("Formulaire envoyé !");
    return true;
}
</script>
